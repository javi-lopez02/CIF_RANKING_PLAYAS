import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

interface schoolDataType {
  name: string;
  country: string;
}
async function main() {
  const schoolData: schoolDataType[] = [
    {
      name: "Angel L. Javier Hernandez",
      country: "República Dominicana",
    },
    {
      name: "Elizabeth Violeta Iris Maldonado",
      country: "México",
    },
    {
      name: "Francisco Detrell",
      country: "México",
    },
    {
      name: "Gianfranco Policastro",
      country: "Argentina",
    },
    {
      name: "Gladys A. Rosado Jimenez",
      country: "Republica Dominicana",
    },
    {
      name: "Gonzalo Méndez Martínez",
      country: "España",
    },
    {
      name: "Jael Javier Olivares",
      country: "República Dominicana",
    },
    {
      name: "Jone Molina",
      country: "España",
    },
    {
      name: "Jose Luis Vasque Almanzar",
      country: "Republica Dominicana",
    },
    {
      name: "Magdalena Sanchez",
      country: "Argentina",
    },
    {
      name: "María José Martín Velasco",
      country: "argentina",
    },
    {
      name: "María Victoria Laitano",
      country: "Argentina",
    },
    {
      name: "Mariana Addino",
      country: "Argentina ",
    },
    {
      name: "Mariana Rosalyth Rondón Ramos",
      country: "Colombia",
    },
    {
      name: "Marie Touchon",
      country: "Colombia/Reino Unido/Francia",
    },
    {
      name: "Ricardo Andrés Arce Torres",
      country: "Chile",
    },
    {
      name: "Sarina Suero Suero",
      country: "República Dominicana",
    },
    {
      name: "Verónica Mariela Blanco",
      country: "Argentina",
    },
    {
      name: "Yadid Adriana Jimenez Zarate",
      country: "colombia",
    },
    {
      name: "Yamila Eliana Rodriguez",
      country: "Argentina",
    },
    {
      name: "Yanel Leonor Martin Varisto",
      country: "Argentina",
    },
    {
      name: "Alessandra Pfuetzenreuter",
      country: "Brasil",
    },
    {
      name: "Bruna Leticia Andrade",
      country: "Brasil",
    },
    {
      name: "Daniel Hauer Queiroz Telles",
      country: "Brasil",
    },
    {
      name: "Fabricio Martinez",
      country: "Brasil",
    },
    {
      name: "Gabriel Moreira Reges",
      country: "Brasil",
    },
    {
      name: "Lucas Silva Leite",
      country: "Brasil",
    },
    {
      name: "Marcus Polette",
      country: "Brasil",
    },
    {
      name: "Neise Mare de Souza Alves",
      country: "Brasil",
    },
    {
      name: "Raija Cisneiros de Jesus Raija",
      country: "Brasil",
    },
  ];

  for (const school of schoolData) {
    await prisma.school.create({
      data: school,
    });
  }
  console.log("Escuela guardada exitosamente.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

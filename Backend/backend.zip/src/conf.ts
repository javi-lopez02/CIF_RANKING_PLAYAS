export const TOKEN_SECRET: string = 'myPassword'

export const SERVER_URL: string = "http://localhost:4000"

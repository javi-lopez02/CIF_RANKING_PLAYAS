// import { Router } from "express";
// import {
//   register,
//   login,
//   logout,
//   confirmEmail,
//   verifyToken,
//   resetPassword,
//   confirmResetPassword
// } from "../Controllers/auth.controller";
// const router = Router();

// router.post("/register", register);

// router.get("/confirm/:token", confirmEmail);

// router.get("/verify", verifyToken);

// router.post("/login", login);

// router.post("/logout", logout);


// router.post("/forgot-password", resetPassword)

// router.post("/reset-password/:token", confirmResetPassword)


// export default router;